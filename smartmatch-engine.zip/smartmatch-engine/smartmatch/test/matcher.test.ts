import { findBestMatches } from "../matcher";
import {
  calculateDistanceKm,
  calculateServiceScore,
  calculateDistanceScore,
  calculateAvailabilityScore,
  calculateRatingScore,
  calculateExperienceScore,
  calculateFinalScore,
  checkAvailability,
} from "../scoring";
import { Worker, CustomerRequest } from "../types";

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function makeWorker(overrides: Partial<Worker> = {}): Worker {
  return {
    id: "w-test",
    name: "Test Worker",
    services: ["Electrical Repair"],
    experience: 5,
    rating: 4.5,
    availability: "available",
    latitude: 28.6315,
    longitude: 77.2167,
    ...overrides,
  };
}

function makeRequest(overrides: Partial<CustomerRequest> = {}): CustomerRequest {
  return {
    serviceRequired: "Electrical Repair",
    customerLocation: { latitude: 28.6315, longitude: 77.2167 },
    preferredDate: "2025-11-20",
    preferredTime: "14:00",
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Distance calculation
// ---------------------------------------------------------------------------

describe("calculateDistanceKm", () => {
  it("returns ~0 for identical coordinates", () => {
    const d = calculateDistanceKm(28.6315, 77.2167, 28.6315, 77.2167);
    expect(d).toBeCloseTo(0, 3);
  });

  it("returns a sensible positive distance for two known points", () => {
    // Connaught Place -> India Gate, roughly ~2.5 km apart
    const d = calculateDistanceKm(28.6315, 77.2167, 28.6129, 77.2295);
    expect(d).toBeGreaterThan(1);
    expect(d).toBeLessThan(5);
  });
});

// ---------------------------------------------------------------------------
// Service matching
// ---------------------------------------------------------------------------

describe("calculateServiceScore", () => {
  it("gives 100 when the worker offers the requested service", () => {
    const worker = makeWorker({ services: ["Electrical Repair", "Fan Installation"] });
    expect(calculateServiceScore(worker, "Electrical Repair")).toBe(100);
  });

  it("gives 0 when the worker does not offer the requested service", () => {
    const worker = makeWorker({ services: ["Plumbing"] });
    expect(calculateServiceScore(worker, "Electrical Repair")).toBe(0);
  });

  it("is case- and whitespace-insensitive", () => {
    const worker = makeWorker({ services: ["  electrical repair  "] });
    expect(calculateServiceScore(worker, "Electrical Repair")).toBe(100);
  });
});

// ---------------------------------------------------------------------------
// Distance scoring
// ---------------------------------------------------------------------------

describe("calculateDistanceScore", () => {
  it("gives 100 at 0 km", () => {
    expect(calculateDistanceScore(0, 10)).toBe(100);
  });

  it("gives 0 at the max distance", () => {
    expect(calculateDistanceScore(10, 10)).toBe(0);
  });

  it("gives 0 beyond the max distance (clamped, never negative)", () => {
    expect(calculateDistanceScore(25, 10)).toBe(0);
  });

  it("gives ~50 at half the max distance", () => {
    expect(calculateDistanceScore(5, 10)).toBe(50);
  });
});

// ---------------------------------------------------------------------------
// Availability
// ---------------------------------------------------------------------------

describe("checkAvailability / calculateAvailabilityScore", () => {
  it("treats an available worker as available", () => {
    const worker = makeWorker({ availability: "available" });
    expect(checkAvailability(worker, makeRequest())).toBe(true);
    expect(calculateAvailabilityScore(true)).toBe(100);
  });

  it("treats a busy worker as unavailable", () => {
    const worker = makeWorker({ availability: "busy" });
    expect(checkAvailability(worker, makeRequest())).toBe(false);
    expect(calculateAvailabilityScore(false)).toBe(0);
  });

  it("treats a matching unavailableSlot as unavailable even if status is 'available'", () => {
    const worker = makeWorker({
      availability: "available",
      unavailableSlots: [{ date: "2025-11-20", time: "14:00" }],
    });
    expect(checkAvailability(worker, makeRequest())).toBe(false);
  });

  it("ignores an unavailableSlot for a different date/time", () => {
    const worker = makeWorker({
      availability: "available",
      unavailableSlots: [{ date: "2025-12-01", time: "09:00" }],
    });
    expect(checkAvailability(worker, makeRequest())).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// Rating
// ---------------------------------------------------------------------------

describe("calculateRatingScore", () => {
  it.each([
    [5.0, 100],
    [4.5, 90],
    [4.0, 80],
    [3.5, 70],
    [0, 0],
  ])("maps rating %s -> score %s", (rating, expected) => {
    expect(calculateRatingScore(rating)).toBeCloseTo(expected, 5);
  });

  it("clamps ratings above 5 to 100", () => {
    expect(calculateRatingScore(7)).toBe(100);
  });

  it("clamps negative ratings to 0", () => {
    expect(calculateRatingScore(-1)).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// Experience
// ---------------------------------------------------------------------------

describe("calculateExperienceScore", () => {
  it.each([
    [2, 20],
    [5, 50],
    [8, 80],
    [10, 100],
  ])("maps %s years -> score %s", (years, expected) => {
    expect(calculateExperienceScore(years, 10)).toBeCloseTo(expected, 5);
  });

  it("caps experience above the max at 100 (30 years does not give 300%)", () => {
    expect(calculateExperienceScore(30, 10)).toBe(100);
  });

  it("gives 0 for 0 years", () => {
    expect(calculateExperienceScore(0, 10)).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// Final score
// ---------------------------------------------------------------------------

describe("calculateFinalScore", () => {
  it("correctly applies the weighted formula from the spec", () => {
    // 100*.35 + 85*.25 + 100*.20 + 96*.10 + 60*.10 = 91.85 -> rounds to 91.9
    // (Note: the spec's own worked example states 90.1, but that figure does
    // not match its own inputs/weights — 91.9 is the arithmetically correct
    // result and is what this implementation produces.)
    const score = calculateFinalScore({
      serviceScore: 100,
      distanceScore: 85,
      availabilityScore: 100,
      ratingScore: 96,
      experienceScore: 60,
    });
    expect(score).toBeCloseTo(91.9, 1);
  });
});

// ---------------------------------------------------------------------------
// findBestMatches — end-to-end scenarios (mirrors the spec's test list)
// ---------------------------------------------------------------------------

describe("findBestMatches", () => {
  it("Test 1 — only returns workers who provide the requested service", () => {
    const workers = [
      makeWorker({ id: "e1", services: ["Electrical Repair"] }),
      makeWorker({ id: "p1", services: ["Plumbing"] }),
    ];
    const results = findBestMatches(makeRequest({ serviceRequired: "Electrical Repair" }), workers);
    expect(results).toHaveLength(1);
    expect(results[0].workerId).toBe("e1");
  });

  it("Test 2 — a closer worker ranks above a farther one, all else equal", () => {
    const near = makeWorker({ id: "near", latitude: 28.6335, longitude: 77.2167 }); // ~0.2km
    const far = makeWorker({ id: "far", latitude: 28.71, longitude: 77.2167 }); // ~8.7km
    const results = findBestMatches(makeRequest(), [far, near]);
    expect(results[0].workerId).toBe("near");
  });

  it("Test 3 — availability is accounted for rather than blindly picking the highest rating", () => {
    const highRatedButBusy = makeWorker({
      id: "busy-high",
      rating: 4.9,
      latitude: 28.6335,
      longitude: 77.2167,
      availability: "busy",
    });
    const availableSlightlyLower = makeWorker({
      id: "avail-ok",
      rating: 4.6,
      latitude: 28.634,
      longitude: 77.2167,
      availability: "available",
    });
    const results = findBestMatches(makeRequest(), [highRatedButBusy, availableSlightlyLower]);
    expect(results[0].workerId).toBe("avail-ok");
  });

  it("Test 4 — with distance/experience/availability equal, higher rating wins", () => {
    const highRating = makeWorker({ id: "hi", rating: 4.9 });
    const lowRating = makeWorker({ id: "lo", rating: 3.8 });
    const results = findBestMatches(makeRequest(), [lowRating, highRating]);
    expect(results[0].workerId).toBe("hi");
  });

  it("Test 5 — with other factors equal, more experience wins", () => {
    const junior = makeWorker({ id: "junior", experience: 2 });
    const senior = makeWorker({ id: "senior", experience: 8 });
    const results = findBestMatches(makeRequest(), [junior, senior]);
    expect(results[0].workerId).toBe("senior");
  });

  it("Test 6 — returns an empty array (not a crash) when no worker matches the service", () => {
    const workers = [makeWorker({ services: ["Plumbing"] })];
    const results = findBestMatches(makeRequest({ serviceRequired: "AC Repair" }), workers);
    expect(results).toEqual([]);
  });

  // -- Additional edge cases -------------------------------------------------

  it("handles an empty worker list without crashing", () => {
    expect(findBestMatches(makeRequest(), [])).toEqual([]);
  });

  it("handles rating = 0 and experience = 0 without crashing or going negative", () => {
    const worker = makeWorker({ rating: 0, experience: 0 });
    const results = findBestMatches(makeRequest(), [worker]);
    expect(results).toHaveLength(1);
    expect(results[0].matchScore).toBeGreaterThanOrEqual(0);
  });

  it("caps experience > max instead of exceeding 100% contribution", () => {
    const overExperienced = makeWorker({ id: "veteran", experience: 30 });
    const atCap = makeWorker({ id: "at-cap", experience: 10 });
    const results = findBestMatches(makeRequest(), [overExperienced, atCap]);
    const veteran = results.find((r) => r.workerId === "veteran")!;
    const capped = results.find((r) => r.workerId === "at-cap")!;
    expect(veteran.scoreBreakdown.experienceScore).toBe(100);
    expect(veteran.matchScore).toBe(capped.matchScore);
  });

  it("handles two workers at the same distance and same score without crashing", () => {
    const a = makeWorker({ id: "a" });
    const b = makeWorker({ id: "b" });
    const results = findBestMatches(makeRequest(), [a, b]);
    expect(results).toHaveLength(2);
    expect(results[0].matchScore).toBe(results[1].matchScore);
  });

  it("handles missing optional data (no unavailableSlots, no skills)", () => {
    const worker = makeWorker({ unavailableSlots: undefined, skills: undefined });
    const results = findBestMatches(makeRequest(), [worker]);
    expect(results).toHaveLength(1);
  });

  it("returns 'Why this worker?' reasons for each result", () => {
    const worker = makeWorker();
    const results = findBestMatches(makeRequest(), [worker]);
    expect(results[0].reasons.length).toBeGreaterThan(0);
    expect(results[0].reasons.some((r) => r.includes("rating"))).toBe(true);
  });

  it("sorts a mixed list highest score first", () => {
    const weak = makeWorker({ id: "weak", rating: 2, experience: 0, availability: "busy" });
    const strong = makeWorker({ id: "strong", rating: 5, experience: 10, availability: "available" });
    const results = findBestMatches(makeRequest(), [weak, strong]);
    expect(results[0].workerId).toBe("strong");
    expect(results[0].matchScore).toBeGreaterThan(results[1].matchScore);
  });
});
